public class Main {    
    public static void main(String[] args) {    
            
        String str1="Remove white spaces";    
            
        //Removes the white spaces using regex    
        str1 = str1.replaceAll("\\s+","");
        System.out.println(str1);
    }    
}