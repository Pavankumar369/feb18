/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    String str = "Nayan";
	    boolean flag = true;
	    str = str.toLowerCase();
	    for(int i = 0;i<str.length()/2;i++){
	        if(str.charAt(i) !=str.charAt(str.length()-i-1)){
	        flag = false;
	        break;}
	    }
	    if(flag){
	        System.out.println("it is a palindrome");
	        
	    }
	    else if(flag=false){
	        System.out.println("it is not a palindrome number");
	        
	    }
		//System.out.println("Hello World");
	}
}
