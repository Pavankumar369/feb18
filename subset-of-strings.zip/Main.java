public class Main{
    public static void main(String[] args){
        String str = "fun";
        int len = str.length();
        int temp = 0;
        String subset[] = new String[(len*(len+1))/2];
        for(int i=0;i<len;i++){
            for(int j=i;j<len;j++){
                subset[temp] = str.substring(i,j+1);
                temp++;
            }
        }
        for(int i=0;i<subset.length;i++){
            System.out.println(subset[i]);
            //subset[i]
        }
    }
}
