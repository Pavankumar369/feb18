/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    String str1 = "abcde";
	    String str2 = "deabc";
	    if(str1.length() != str2.length()){
	        System.out.println("str2 is not a rotation of str1");
	    }
	    else{
	    str1 = str1.concat(str1);
	    if(str1.indexOf(str2)!=-1){
	        System.out.println("str2 is a rotation of str1");
	        
	    }
	    else{
	        System.out.println("str2 is not a rotation of str1");
	        }
	        
	    }
		//System.out.println("Hello World");
	}
}
